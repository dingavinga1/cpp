/*OOP PROJECT
Abdullah Irfan
20I-2702
Cybersecurity-T*/

#include<iostream>
#include<string>
#include<cstring>
#include<sstream>
#include<fstream>
#include<cmath>
#include<cstdlib>
#include<time.h>
#include<vector>

using namespace std;

class system;
class person;
class passenger;
class admin;
class flight;
class international;
class local;

struct airplane{
	int id;
	string city;
	string location;
};

struct time_f{
	short hour;
	short min;
};

class flight{
protected:
	time_f deptime;
	time_f arrtime;
	time_f duration;
	int id;
	int e_occ;
	int b_occ;
	int capacity=60;
	int stops;
	int price;
	int tax;
	stringstream depport; //bonus work
	stringstream arrport; //bonus work
	airplane pl;
public:
	int gettotalprice();
	int getcapacity();
	int geteocc();
	int getbocc();
	void setdeptime(time_f t);
	void setid(int id);
	void seteocc(int occ);
	void setbocc(int occ);
	void setcapacity(int c);
	void setstops(int st);
	virtual void cal_price()=0; //bonus work (abstract class)
	void setdepport(string city, string loc);
	void setarrport(string city, string loc);
	void setplane(airplane p);
	friend ostream& operator<<(ostream& out, flight& obj);
	virtual void getcountry(string c, int d);
};

int flight::gettotalprice(){
	return price+tax;
}

int flight::getcapacity(){
	return capacity;
}

void flight::getcountry(string c, int d){}

void flight::setdeptime(time_f t){
	deptime=t;
}

void flight::setid(int id){
	this->id=id;
}

void flight::seteocc(int occ){
	e_occ=occ;
}

void flight::setbocc(int occ){
	b_occ=occ;
}

void flight::setcapacity(int c){
	capacity=c;
}

void flight::setstops(int st){
	stops=st;
}

void flight::setdepport(string city, string loc){
	depport<<loc<<' '<<city;
}

void flight::setarrport(string city, string loc){
	arrport<<loc<<' '<<city;
}

void flight::setplane(airplane p){
	pl=p;
}

int flight::geteocc(){
	return e_occ;
}

int flight::getbocc(){
	return b_occ;
}

ostream& operator<<(ostream& out, flight& obj){
	string temp1, temp2;
	obj.arrport>>temp1>>temp2;
	string tempx1, tempx2;
	obj.depport>>tempx2>>tempx1;
	out<<"ID: "<<obj.id<<endl<<endl;
	out<<"Airplane: "<<obj.pl.id<<endl;
	out<<"Departure: "<<endl;
	out<<"Time: "<<obj.deptime.hour<<":"<<obj.deptime.min<<endl;
	out<<"City: "<<tempx1;
	out<<" ";
	out<<tempx2<<endl;
	out<<"Arrival: "<<endl;
	out<<"Time: "<<obj.arrtime.hour<<":"<<obj.arrtime.min<<endl;
	out<<"City: "<<temp2<<" "<<temp1<<endl;
	out<<"Seats in business: "<<10-obj.b_occ<<endl;
	out<<"Seats in economy: "<<50-obj.e_occ<<endl;
	out<<"Price: "<<obj.price+obj.tax<<endl;
	return out;
}


class international:public flight{
	string country;
	int dist;
public:
	void getcountry(string c, int d);
	void cal_price();
	friend ostream& operator<<(ostream& out, international& obj);
};

void international::getcountry(string c, int d){
	country=c;
	dist=d;
}

void international::cal_price(){
	duration.hour=dist/400;
	duration.min=rand()%40+10;
	arrtime.hour=duration.hour+deptime.hour;
	arrtime.min=duration.min+deptime.min;
	price=duration.hour*20000;
	tax=0.1*price;
}

ostream& operator<<(ostream& out, international& obj){
	string tempx1, tempx2;
	obj.depport>>tempx1>>tempx2;
	out<<"ID: "<<obj.id<<endl<<endl;
	out<<"Airplane: "<<obj.pl.id<<endl;
	out<<"Departure: "<<endl;
	out<<"Time: "<<obj.deptime.hour<<":"<<obj.deptime.min<<endl;
	out<<"City: "<<tempx1<<" "<<tempx2<<endl;
	out<<"Arrival: "<<endl;
	out<<"Time: "<<obj.arrtime.hour<<":"<<obj.arrtime.min<<endl;
	out<<"Country: "<<obj.country<<endl;
	out<<"Stops: "<<obj.stops<<endl;
	out<<"Seats in business: "<<10-obj.b_occ<<endl;
	out<<"Seats in economy: "<<50-obj.e_occ<<endl;
	out<<"Price: "<<obj.price+obj.tax<<endl;
	return out;
}

class local:public flight{
public:
	void cal_price();
};

void local::cal_price(){
	duration.hour=rand()%5+1;
	duration.min=rand()%40+10;
	price=duration.hour*10000;
	tax=0.05*price;
	arrtime.hour=duration.hour+deptime.hour;
	arrtime.min=duration.min+deptime.min;
}

class person{
protected:
	string username;
	string password;
public:
	void setus(string us);
	void setpass(string pass);
	virtual void storedeets()=0; //bonus work (abstract class)
};

void person::setus(string us){
	username=us;
}

void person::setpass(string pass){
	password=pass;
}

void person::storedeets(){
	fstream guy("passenger.txt", ios::in|ios::out|ios::app);
	guy<<username<<' '<<password<<endl;
	guy.close();
}

class passenger:public person{
	international* intfl;
	local* locfl;
public:
	bool loc;
	bool fl=false;
	int getprice();
	void storedeets();
	void addcurr(international* fl);
	void addcurr(local* fl);
	void displayflight();
};

void passenger::displayflight(){
	if(loc)
		cout<<*locfl;
	else
		cout<<*intfl;
}

int passenger::getprice(){
	if(loc)
		return locfl->gettotalprice();
	else
		return intfl->gettotalprice();
}

void passenger::storedeets(){
	fstream guy("passenger.txt", ios::in|ios::out|ios::app);
	guy<<username<<' '<<password<<endl;
	guy.close();
}

void passenger::addcurr(international* fl){
	loc=false;
	intfl=fl;
	this->fl=true;
}

void passenger::addcurr(local* fl){
	loc=true;
	locfl=fl;
	this->fl=true;
}

class admin:public person{
	string occ;
public:
	void storedeets();
	void setocc(string occ);
	string getocc();
};

void admin::storedeets(){}

void admin::setocc(string occu){
	this->occ=occu;
}

string admin::getocc(){
	return this->occ;
}

class System{
	international world[40];
	local domestic[100];
	airplane planes[100];
	passenger user;
	admin manager;
public:
	System();
	void initworld();
	void initdomestic();
	void initplanes();
	char login();
	void showflights();
};

System::System(){
	initplanes();
	initworld();
	initdomestic();
	in_syslogin:
	char choice=login();
	switch(choice){
			case 'a':{
				in_admin:
				cout<<"\n\n\n";
				cout<<"1. Show flights\n";
				cout<<"2. Settings for International Flights\n";
				cout<<"3. Settings for Domestic Flights\n";
				cout<<"4. Logout\n";
				int choice2;
				cin>>choice2;
				switch(choice2){
					case 1:{
						showflights();
						goto in_admin;
						break;
					}
					case 2:{
						in_inter:
						cout<<"\n\n\n";
						int id;
						cout<<"Enter ID: ";
						cin>>id;
						if(id<1||id>40){
							cout<<"Invalid ID. Please re-enter\n";
							goto in_inter;
						}
						in_inter_choice:
						cout<<"\n\n\n";
						cout<<"1. Change capacity\n";
						cout<<"2. Change stops\n";
						cout<<"3. Change departure time\n";
						cout<<"4. Quit\n";
						int choice3;
						cin>>choice3;
						if(choice3==1){
							int temp;
							cout<<"Enter new capacity: ";
							cin>>temp;
							world[id-1].setcapacity(temp);
							cout<<"Update successful\n";
							goto in_inter_choice;
						}
						else if(choice3==2){
							int temp;
							cout<<"Enter number of stops: ";
							cin>>temp;
							world[id-1].setstops(temp);
							cout<<"Update successful\n";
							goto in_inter_choice;
						}
						else if(choice3==3){
							in_time:
							int temp, tempm;
							cout<<"Enter hour: ";
							cin>>temp;
							if(temp<0||temp>23){
								cout<<"Invalid input. Please re-enter\n";
								goto in_time;
							}	
							cout<<"Enter min: ";
							cin>>tempm;
							if(temp<0||temp>59){
								cout<<"Invalid input. Please re-enter\n";
								goto in_time;
							}
							time_f temptime;
							temptime.hour=temp;
							temptime.min=tempm;
							world[id-1].setdeptime(temptime);
							world[id-1].cal_price();
							cout<<"Update Successful\n";
							goto in_inter_choice;
						}				
						else if(choice3==4){
							goto in_admin;
						}
						else{
							cout<<"Invalid choice. Please re-enter\n";
							goto in_inter_choice;
						}
					}	
					case 3:{
						in_dom:
						cout<<"\n\n\n";
						int id;
						cout<<"Enter ID: ";
						cin>>id;
						if(id<1||id>100){
							cout<<"Invalid ID. Please re-enter\n";
							goto in_inter;
						}
						in_dom_choice:
						cout<<"\n\n\n";
						cout<<"1. Change capacity\n";
						cout<<"2. Change departure time\n";
						cout<<"3. Quit\n";
						int choice3;
						cin>>choice3;
						if(choice3==1){
							int temp;
							cout<<"Enter new capacity: ";
							cin>>temp;
							domestic[id-1].setcapacity(temp);
							cout<<"Update successful\n";
							goto in_dom_choice;
						}
						else if(choice3==2){
							in_time2:
							int temp, tempm;
							cout<<"Enter hour: ";
							cin>>temp;
							if(temp<0||temp>23){
								cout<<"Invalid input. Please re-enter\n";
								goto in_time2;
							}
						
							cout<<"Enter min: ";
							cin>>tempm;
							if(temp<0||temp>59){
								cout<<"Invalid input. Please re-enter\n";
								goto in_time2;
							}
							time_f temptime;
							temptime.hour=temp;
							temptime.min=tempm;
							domestic[id-1].setdeptime(temptime);
							domestic[id-1].cal_price();
							cout<<"Update Successful\n";
							goto in_dom_choice;
						}
						else if(choice3==3){
							goto in_admin;
						}
						else{
							cout<<"Invalid choice. Please re-enter\n";
							goto in_admin;
						}
					}
					case 4:{
						goto in_syslogin;
					}
				}
			}
			case 'p':{
					showflights();
					in_passenger:
					cout<<"\n\n\n";
					cout<<"1. Book flight\n";
					cout<<"2. Cancel flight\n";
					cout<<"3. Your flight\n";
					cout<<"4. Logout\n";
					int choice2;
					cin>>choice2;
					switch(choice2){
						case 1:{
							in_locint:
							cout<<"\n\n\n";
							cout<<"1. Local\n";
							cout<<"2. International\n";
							cout<<"3. Quit\n";
							int choice3;
							cin>>choice3;
							cout<<"Enter flight id: ";
							int id;
							cin>>id;
							if(choice3==1){
								if(id<1||id>100){
									cout<<"Invalid id. Please re-enter\n";
									goto in_locint;
								}
								if(domestic[id-1].geteocc()+domestic[id-1].getbocc()==domestic[id-1].getcapacity()){
									cout<<"Plane is full\n";
									goto in_locint;
								}
								user.addcurr(&domestic[id-1]);
								cout<<"Flight booked successfully\n";
								goto in_passenger;
							}
							else if(choice3==2){
								if(id<1||id>40){
									cout<<"Invalid id. Please re-enter\n";
									goto in_locint;
								}
								if(world[id-1].geteocc()+world[id-1].getbocc()==world[id-1].getcapacity()){
									cout<<"Plane is full\n";
									goto in_locint;
								}
								user.addcurr(&world[id-1]);
								cout<<"Flight booked successfully\n";
								goto in_passenger;
							}
							else if(choice==3){
								goto in_passenger;
							}
							else{
								cout<<"Invald choice. Please re-enter\n";
								goto in_locint;
							}
						}
						case 2:{
							if(user.fl){
								user.fl=false;
								cout<<"Fine: "<<0.25*user.getprice();
							}
							goto in_passenger;
						}
						case 3:{
							if(!user.fl){
								cout<<"No booked flights\n";
								goto in_passenger;
							}
							user.displayflight();
							goto in_passenger;
						}
						case 4:{
							goto in_syslogin;
						}
				}
			}
			case 'i':{
				return;
			}
		}
}

void System::showflights(){
	cout<<"------LOCAL FLIGHTS------\n\n";
	for(int i=0; i<100; i++){
		cout<<domestic[i];
			cout<<endl;
	}
	cout<<"------INTERNATIONAL FLIGHTS------\n\n";
	for(int i=0; i<40; i++){
		cout<<world[i];
		cout<<endl;
	}
}

void System::initworld(){
	srand(time(NULL));
	string cities[]={"Quetta", "Karachi", "Islamabad", "Peshawar", "Lahore"};
	string loc[]={"North", "South"};
	for(int i=0; i<40; i++){
		time_f temptime;
		temptime.hour=rand()%23;
		temptime.min=rand()%40+10;
		world[i].setdeptime(temptime);
		world[i].setid(i+1);
		world[i].seteocc(rand()%49);
		world[i].setbocc(rand()%9);
		world[i].setstops(rand()%3);
		world[i].setplane(planes[rand()%49+50]);
		world[i].setdepport(cities[rand()%5], loc[rand()%2]);
		int count=rand()%24+1;
		int tempcount=0;
		//bonus work (file handling used to access countries available and their distance)
		fstream countries("countries.txt", ios::in);
		string c;
		int d;
		string buff;
		while(getline(countries, buff)&&tempcount<=count){
			stringstream ss(buff);
			ss>>c;
			ss>>d;
			tempcount++;
		}
		countries.close();
		world[i].getcountry(c, d);
		world[i].cal_price();
	}
}

void System::initdomestic(){
	string cities[]={"Quetta", "Karachi", "Islamabad", "Peshawar", "Lahore"};
	string loc[]={"North", "South"};
	for(int i=0; i<100; i++){
		time_f temptime;
		temptime.hour=rand()%23;
		temptime.min=rand()%40+10;
		domestic[i].setdeptime(temptime);
		domestic[i].setid(i+1);
		domestic[i].seteocc(rand()%49);
		domestic[i].setbocc(rand()%9);
		domestic[i].setplane(planes[rand()%49+50]);
		domestic[i].setdepport(cities[rand()%5], loc[rand()%2]);
		domestic[i].setarrport(cities[rand()%5], loc[rand()%2]);
		domestic[i].cal_price();
	}
}

void System::initplanes(){
	string cities[]={"Quetta", "Karachi", "Islamabad", "Peshawar", "Lahore"};
	string loc[]={"North", "South"};
	int planecount=0;
	int citycount=0;
	int loccount=0;
	for(; planecount<100; planecount++){
		planes[planecount].id=planecount+1;
		planes[planecount].city=cities[citycount];
		planes[planecount].location=loc[loccount];
		if((loccount+1)%2==0)
			loccount++;
		if((citycount+1)%5==0)
			citycount++;
	}
}

char System::login(){
	in_login:
	cout<<"\n\n\n";
	cout<<"------WELCOME TO NEW PAK AIRLINE FLIGHT SYSTEM------\n\n";
	cout<<"New-PAK Airline Flight System (NPAFS) is a newly established airline, functional in 5 major cities of pakistan (Islamabad, Lahore, Quetta, Peshawar and Karachi).\n";
	cout<<"Each city has two airports- North and South. NPAFS has established a network with around 25 countries around the globe. Some countries may have travel bans due to COVID-19.\n";
	cout<<"NPAFS greatly values itss passengers and abides by international travelling laws. NPAFS has a network of around 50000 passengers per annum.\n";
	cout<<"During COVID days, economy class can hold 50 passengers while business can hold 10. There will be a gap of one seat between two passengers. Thank you.\n\n\n";
	cout<<"1. Login as Admin\n";
	cout<<"2. Login as User\n";
	cout<<"3. Quit\n";
	int choice1;
	cin>>choice1;
	switch(choice1){
		case 1:{
			fstream admin1("admin.txt", ios::in);
			in_admin:
			cout<<"\n\n\n";
			string desig;
			cout<<"Enter your designation: ";
			cin>>desig;
			string username;
			cout<<"Username: ";
			cin>>username;
			string password;
			cout<<"Password: ";
			cin>>password;
			cout<<endl;
			while(!admin1.eof()){
				string buff;
				while(getline(admin1, buff)){
					stringstream ss(buff);
					string tempus, temppass;
					ss>>tempus>>temppass;
					if(tempus==username&&temppass==password){
						cout<<"Login successful...\n";
						manager.setus(tempus);
						manager.setpass(temppass);
						manager.setocc(desig);
						admin1.close();
						return 'a';
					}
				}
			}
			cout<<"Invalid Credentials. Please re-enter\n";
			admin1.close();
			goto in_admin;
			break;
		}
		case 2:{
			in_pass_main:
			cout<<"\n\n\n";
			cout<<"1. Signin\n";
			cout<<"2. Signup\n";
			cout<<"3. Return to main menu\n";
			int choice2;
			cin>>choice2;
			switch(choice2){
				case 1:{
					fstream file("passenger.txt", ios::in);
					in_pass:
					string username;
					cout<<"Username: ";
					cin>>username;
					string password;
					cout<<"Password: ";
					cin>>password;
					cout<<endl;
					while(!file.eof()){
						string buff;
						while(getline(file, buff)){
							stringstream ss(buff);
							string tempus, temppass;
							ss>>tempus>>temppass;
							if(tempus==username&&temppass==password){
								cout<<"Login successful...\n";
								user.setus(tempus);
								user.setpass(temppass);
								file.close();
								return 'p';
							}
						}
					}
					cout<<"Invalid Credentials. Please re-enter\n";
					file.close();
					goto in_pass;
					break;
				}
				case 2:{
					cout<<"---Sign Up---\n";
					string temp;
					cout<<"Enter your name: ";
					cin>>temp;
					cout<<"Enter your gender: ";
					cin.ignore();
					cin>>temp;
					int age;
					cout<<"Enter your age: ";
					cin>>age;
					in_cnic:
					cout<<"\n\n\n";
					if(age<18)
						cout<<"If you have an adult CNIC, you can proceed\n";
					cout<<"CNIC: ";
					long long cnic;
					cin>>cnic;
					if(cnic<9999999999999&&cnic>999999999999){}
					else{
						cout<<"Invalid CNIC. Please re-enter\n";
						goto in_cnic;
					}
					string username;
					string password, confirm;
					cout<<"Username: ";
					cin>>username;
					in_password:
					cout<<"\n\n\n";
					cout<<"Password (atleast 1 symbol, 1 digit and 1 alphabet): ";
					cin>>password;
					cout<<endl;
					int sym=0, num=0, alp=0;
					for(int i=0; i<password.length(); i++){
						char temp;
						stringstream ss(password.substr(i, i+1));
						ss>>temp;
						if(temp>'A'&&temp<'Z')
							alp++;
						else if(temp>'a'&&temp<'z')
							alp++;
						else if(temp>'0'&&temp<'9')
							num++;
						else
							sym++;
					}
					if(sym>1&&num>1&&alp>1&&password.length()>7){
						cout<<"Confirm password: ";
						cin>>confirm;
						cout<<endl;
						if(password!=confirm){
							cout<<"Passwords do not match\n";
							goto in_password;
						}
						cout<<"Signup successful...\n";
						passenger temppassen;
						temppassen.setus(username);
						temppassen.setpass(password);
						temppassen.storedeets();
						user=temppassen;
						return 'p';
					}
					else{
						cout<<"Invalid password. Please re-enter\n";
						goto in_password;
					}
					break;

				}
				case 3:{
					goto in_login;
					break;
				}
				default:{
					cout<<"Invalid choice. Please re-enter\n";
					goto in_pass_main;
				}
			}

		}
		case 3:{
			return 'i';
			break;
		}
		default:{
			cout<<"Invalid choice. Please re-enter\n\n\n";
			goto in_login;
		}
	}

}

int main(){
	srand(time(NULL));
	System start;

	return 0;
}
